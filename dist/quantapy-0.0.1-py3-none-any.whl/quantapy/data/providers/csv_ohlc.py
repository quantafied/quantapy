"""
CSV OHLC provider for local/user-uploaded market data.

This provider is intentionally small: the API is responsible for accepting a
browser upload and storing it on the server, while this provider reads the
resulting path into a DataFrame.
"""

from pathlib import Path
from typing import Dict

import pandas as pd

from quantapy.data.providers.base import BaseProvider
from quantapy.registry.component_registry import register_component


class CSVProvider(BaseProvider):
    """Read arbitrary CSV data into a named DataFrame."""

    config = {
        "title": "CSV File",
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "default": "",
                "description": "CSV file",
                "widget_type": "file",
            },
            "source_id": {
                "type": "string",
                "default": "CSV",
                "description": "Dataset name",
            },
            "date_column": {
                "type": "string",
                "default": "date",
                "description": "Date/time column",
            },
            "parse_dates": {
                "type": "string",
                "default": "true",
                "description": "Parse the date column",
                "enum": ["true", "false"],
                "widget_type": "select",
            },
            "delimiter": {
                "type": "string",
                "default": ",",
                "description": "CSV delimiter",
            },
        },
    }

    def execute(self) -> Dict[str, pd.DataFrame]:
        """Read a CSV into a named DataFrame."""
        path = Path(str(self.params.get("path") or "")).expanduser()
        if not path.exists():
            raise FileNotFoundError(f"CSV path does not exist: {path}")

        delimiter = str(self.params.get("delimiter") or ",")
        df = pd.read_csv(path, sep=delimiter)
        date_column = str(self.params.get("date_column") or "date")
        if date_column in df.columns and date_column != "date":
            df = df.rename(columns={date_column: "date"})
            date_column = "date"
        if str(self.params.get("parse_dates", "true")).lower() == "true" and date_column in df.columns:
            df[date_column] = pd.to_datetime(df[date_column], errors="ignore")

        source_id = str(self.params.get("source_id") or path.stem)
        return {source_id: df}


@register_component(category="Dataset", function="CSV", source="Local")
class CSV(CSVProvider):
    """Generic local/uploaded CSV provider."""


@register_component(category="Market", function="OHLC", source="CSV")
class OHLC(CSVProvider):
    """Backward-compatible CSV source for OHLC workflows."""
